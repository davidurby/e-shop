<?php
    $server = "localhost";
    $login = "root";
    $password = "";
    $database = "skoleni";

    $connection = new mysqli($server, $login, $password, $database);
?>