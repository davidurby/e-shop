<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Vítejte v administraci Demo e-shopu</h1>
    <h2>Kam budeme pokračovat?</h2>
    <ul>
        <li><a href="categories.php">Spravovat kategorie</a></li>
        <li><a href="products.php">Spravovat produkty</a></li>
    </ul>
</body>
</html>